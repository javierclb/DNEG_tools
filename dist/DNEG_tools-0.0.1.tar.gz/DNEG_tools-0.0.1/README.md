# PLP_Output

Libreria para tratamiento de salidas PLP con Spark y Python.
# PLP_Out
